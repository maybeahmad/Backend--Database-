import { products } from "../db.js";
import Product from "../models/productSchema.js";


export const getallProduct = function (req, res,) {
    res.json(products);
}

export  const getProductbyid = function (req, res,) {
    res.json(products);
}

export  const createNewproduct = function (req, res,) {
Product.create();
    res.json(products);
}

export  const updateProduct = function (req, res,) {
    res.json(products);
}

export const deleteProduct = function (req, res,) {
    res.json(products);
}