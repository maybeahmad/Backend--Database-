import mongoose from "mongoose";
const { Schema } = mongoose;

const productSchema = new Schema({
    title:{
        type:String,
        require:true,
        min:[5, "title must consist of 5 letters"]
     },
     description:{
        type:String,
        require:true,
        min:[5, "title must consist of 5 letters"]
     },
     catagory:{
        type:String,
        require:true,
        min:[5, "title must consist of 5 letters"]
     },
     price:{
        type:Number,
        require:true,
        min:[5, "title must consist of 5 letters"]
     },
     rating:{
        type:Number,
        require:true,
        min:[5, "title must consist of 5 letters"]
     }
})

const Product = mongoose.model('product', productSchema )

export default Product;