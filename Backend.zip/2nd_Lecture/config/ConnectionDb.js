import mongoose from "mongoose";
//Network request is always asynchoronious
export const dbconnection = async ()=>{

try{
    const res = await mongoose.connect('mongodb://127.0.0.1:27017/Ecommerce');
    console.log('Connection successful', res.connection.port)
} 
catch (error) {
  console.log('Error while getting data from Database', error)
}

}