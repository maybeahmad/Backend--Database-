import express  from "express";
import router from "./routes/ProductRoute.js";
import { dbconnection } from "./config/COnnectionDb.js";

const app = express();

const port = 3000;
dbconnection();
app.use('/api',router)
app.listen(port,()=>{
    console.log(`server is listening on ${port}`)
})