import express from 'express';
const router = express.Router();
import { createNewproduct,deleteProduct,updateProduct,getProductbyid, getallProduct} from '../controller/ControllerProduct.js';

router.route('/products').get(getallProduct);
router.route('/products:/id').get(getProductbyid);
router.route('/products').post(createNewproduct);
router.route('/products/:id').put(updateProduct);
router.route('/products/:id').delete(deleteProduct);

export default router;